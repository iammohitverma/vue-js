<template>
  <MainWeb/>
</template>

<script>
import MainWeb from './components/MainWeb.vue'

export default {
  name: 'App',
  components: {
    MainWeb
  }
}
</script>
