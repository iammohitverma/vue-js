import { createWebHistory, createRouter } from "vue-router";
import Home from "./components/pages/HomePage.vue";
import AboutPage from "./components/pages/AboutPage.vue";

const routes = [
    {
        name : 'Home',
        path : '/',
        component : Home
    },
    {
        name : 'About',
        path : '/about',
        component : AboutPage
    },
]

const router = createRouter({
    history : createWebHistory(),
    routes
});
export default router;