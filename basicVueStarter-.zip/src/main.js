import { createApp } from 'vue'
import App from './App.vue'
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap'; 

import './enqeue_styles.js';

import router from './routes.js'


createApp(App).use(router).mount('#app')