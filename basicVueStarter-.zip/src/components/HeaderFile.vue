<template>
    <header>
        <div class="container">
            <div class="inner">
                <div class="loago_wrap">
                    <router-link to="/"> LOGO </router-link>
                </div>
                <nav>
                    <ul>
                        <li>
                            <router-link to="/"> Home </router-link>
                        </li>
                        <li>
                            <router-link to="/about"> About </router-link>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
</template>

<script>
export default {
    name: "HeaderFile"
}
</script>
