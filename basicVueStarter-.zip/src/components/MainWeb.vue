<template>
    <HeaderFile />
    <main>
        <router-view></router-view>
    </main>
    <FooterFile />
</template>

<script>
import HeaderFile from './HeaderFile.vue'
import FooterFile from './FooterFile.vue'

export default {
    name: 'MainWeb',
    components: {
        HeaderFile,
        FooterFile
    }
}
</script>
