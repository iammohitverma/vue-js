<template>
<footer>
    <div class="container">
        <h3>Footer</h3>
        <p> &#169; {{copyrightYear}} <a href="https://techmind.co.in/" target="_blank"> Techmind Softwares </a> | All rights reserved </p>
    </div>
</footer>
</template>

<script>
export default {
    name: "FooterFile",

    data() {
        return {
            copyrightYear: 2022,
        }
    },

    methods:{
        getCurrentYear(){
            const date = new Date();
            const year = date.getFullYear();
            this.copyrightYear = year;
            console.log(this.copyrightYear);
        }
    },

    mounted() {
        this.getCurrentYear();
    }
}
</script>
