<template>
    <section class="aboutHero">
        <div class="container">
            <h1>About Page</h1>
        </div>
    </section>
</template>


<script>
export default {
    name: "AboutPage",
}
</script>