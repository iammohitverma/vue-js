<template>
    <section class="hero">
        <div class="container">
            <h1>Home Page</h1>
        </div>
    </section>
</template>


<script>
export default {
    name: "HomePage",
}
</script>