<template>
  <main>
    <!-- homeBanner -->
    <section class="container-fluid homeBanner textDark">
      <div class="container">
        <div class="row d-flex justify-content-center flex-md-reverse">
          <div class="col-12 col-sm-10 col-md-11 col-lg-10 col-xl-11">
            <div class="row">
              <div class="col-12 col-md-7 d-flex align-items-center">
                <div class="inner">
                  <h1 class="hdng">
                    Global Cloud Communication Innovator, always remembering our
                    values
                    <!-- Global Cloud Communication <br />Innovator -->
                  </h1>
                  <p class="cntnt">
                    Anchored in Singapore for Global expansion
                  </p>
                </div>
              </div>
              <div class="col-12 col-md-5 mt-4 mt-md-0">
                <img src="../../assets/images/company_banner.png" alt="" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- company_desc -->
    <section class="company_desc pb_100">
      <div class="container">
        <div class="sec_heading text-center">
          <h2>Company Profile</h2>
          <p>
            Singapore-headquartered NXCLOUD offers communication solutions and
            services that simplify global customer engagement for businesses of
            all sizes. Our robust APIs, zero-code services and unified customer
            engagement platform streamline communications from messaging to
            voice calls, eliminating siloed channels, complex integration and
            limited reach. Serving over 10,000 clients across 185 countries, we
            have been instrumental in expanding our clients’ business presence
            globally, quickly and flexibly thus creating new opportunities and
            revenue growth.
          </p>
        </div>
        <div class="content_2 desktop">
          <h3>Core Values</h3>
          <div class="row">
            <div class="col-md-6 col-lg-4">
              <div class="company_profile_card">
                <h3>Sincerity</h3>
                <div class="details">
                  <p>
                    Simple and sincere, treating others openly. Upholding a
                    genuine and straightforward approach, being fair and
                    impartial. Addressing issues directly with proposed
                    solutions, focusing on the matter at hand rather than
                    personalizing conflicts.
                  </p>

                  <ul class="tags">
                    <li>
                      <a href="#">Equal</a>
                    </li>
                    <li>
                      <a href="#">Fair</a>
                    </li>
                    <span class="empty_break"></span>
                    <li>
                      <a href="#">Simple</a>
                    </li>
                    <li>
                      <a href="#">Reliable</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4">
              <div class="company_profile_card">
                <h3>Professional</h3>
                <div class="details">
                  <p>
                    Independent and customer focus, specialize in the subject,
                    continuously learn, focus on the professional practice and
                    improvement. Put the customer needs first, with customer
                    benefits as the starting point, providing lasting and
                    superior value.
                  </p>

                  <ul class="tags">
                    <li>
                      <a href="#">Customer focus</a>
                    </li>
                    <li>
                      <a href="#">Professional</a>
                    </li>
                    <span class="empty_break"></span>
                    <li>
                      <a href="#">Attitude</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4">
              <div class="company_profile_card">
                <h3>Perseverance</h3>
                <div class="details">
                  <p>
                    Stay true to the original aspiration, forge ahead. Dare to
                    strive, be resilient under pressure, self-driven, face
                    challenges with unwavering determination
                  </p>

                  <ul class="tags">
                    <li>
                      <a href="#">Consistent</a>
                    </li>
                    <li>
                      <a href="#">Resilent</a>
                    </li>
                    <span class="empty_break"></span>
                    <li>
                      <a href="#">Entrepreneurial</a>
                    </li>
                    <li>
                      <a href="#">Long-term perspective</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4">
              <div class="company_profile_card">
                <h3>Collaboration</h3>
                <div class="details">
                  <p>
                    Build mutual trust, establish common goals and collaborate
                    with the stakeholders. Be inclusive, understand and
                    acknowledge individual differences. Appreciate and trust
                    each other, uphold principles while being adept at
                    compromise; create a collaborative and win-win atmosphere.
                  </p>

                  <ul class="tags">
                    <li>
                      <a href="#">Common goals</a>
                    </li>
                    <li>
                      <a href="#">Trust</a>
                    </li>
                    <span class="empty_break"></span>
                    <li>
                      <a href="#">Empathetic</a>
                    </li>
                    <li>
                      <a href="#">Cross functional</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4">
              <div class="company_profile_card">
                <h3>Responsibility</h3>
                <div class="details">
                  <p>
                    Diligent and responsible, taking practical actions.
                    Possessing an entrepreneurial spirit, addressing tasks
                    promptly, correcting mistakes quickly, working steadfastly,
                    daring to take responsibility, pursuing success, and never
                    admitting defeat.
                  </p>

                  <ul class="tags">
                    <li>
                      <a href="#">Practical</a>
                    </li>
                    <li>
                      <a href="#">Responsible</a>
                    </li>
                    <span class="empty_break"></span>
                    <li>
                      <a href="#">Ownership</a>
                    </li>
                    <li>
                      <a href="#">Reflection</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4">
              <div class="company_profile_card">
                <h3>Innovation</h3>
                <div class="details">
                  <p>
                    Innovation-driven, pursuing excellence. Rejecting
                    complacency and stagnation, maintaining curiosity towards
                    new things, continually bringing value to the business
                    through innovative products, services, and management
                    modelst
                  </p>

                  <ul class="tags">
                    <li>
                      <a href="#">Inspiring</a>
                    </li>
                    <li>
                      <a href="#">Open</a>
                    </li>
                    <span class="empty_break"></span>
                    <li>
                      <a href="#">Innovative</a>
                    </li>
                    <li>
                      <a href="#">Sharing</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content_2 mobile">
          <h3>Core Values</h3>
          <div class="row">
            <div class="coreValues swiperSlider numberNav slider_equal_height">
              <swiper
                :modules="modules"
                :slides-per-view="1"
                :space-between="20"
                :equal-height="true"
                :autoplay="{ delay: 5000, disableOnInteraction: true }"
                :loop="true"
                navigation
                :pagination="{ clickable: true }"
                @swiper="coreValuesSliderSwiper"
                @slideChange="coreValuesSliderSlideChange"
              >
                <swiper-slide class="item">
                  <div class="col-md-12">
                    <div class="company_profile_card">
                      <h3>Sincerity</h3>
                      <div class="details">
                        <p>
                          Simple and sincere, treating others openly. Upholding
                          a genuine and straightforward approach, being fair and
                          impartial. Addressing issues directly with proposed
                          solutions, focusing on the matter at hand rather than
                          personalizing conflicts.
                        </p>

                        <ul class="tags">
                          <li>
                            <a href="#">Equal</a>
                          </li>
                          <li>
                            <a href="#">Fair</a>
                          </li>
                          <span class="empty_break"></span>
                          <li>
                            <a href="#">Simple</a>
                          </li>
                          <li>
                            <a href="#">Reliable</a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </swiper-slide>
                <swiper-slide class="item">
                  <div class="col-md-12">
                    <div class="company_profile_card">
                      <h3>Professional</h3>
                      <div class="details">
                        <p>
                          Independent and customer focus, specialize in the
                          subject, continuously learn, focus on the professional
                          practice and improvement. Put the customer needs
                          first, with customer benefits as the starting point,
                          providing lasting and superior value.
                        </p>

                        <ul class="tags">
                          <li>
                            <a href="#">Customer focus</a>
                          </li>
                          <li>
                            <a href="#">Professional</a>
                          </li>
                          <span class="empty_break"></span>
                          <li>
                            <a href="#">Attitude</a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </swiper-slide>
                <swiper-slide class="item">
                  <div class="col-md-12">
                    <div class="company_profile_card">
                      <h3>Perseverance</h3>
                      <div class="details">
                        <p>
                          Stay true to the original aspiration, forge ahead.
                          Dare to strive, be resilient under pressure,
                          self-driven, face challenges with unwavering
                          determination
                        </p>

                        <ul class="tags">
                          <li>
                            <a href="#">Consistent</a>
                          </li>
                          <li>
                            <a href="#">Resilent</a>
                          </li>
                          <span class="empty_break"></span>
                          <li>
                            <a href="#">Entrepreneurial</a>
                          </li>
                          <li>
                            <a href="#">Long-term perspective</a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </swiper-slide>
                <swiper-slide class="item">
                  <div class="col-md-12">
                    <div class="company_profile_card">
                      <h3>Collaboration</h3>
                      <div class="details">
                        <p>
                          Build mutual trust, establish common goals and
                          collaborate with the stakeholders. Be inclusive,
                          understand and acknowledge individual differences.
                          Appreciate and trust each other, uphold principles
                          while being adept at compromise; create a
                          collaborative and win-win atmosphere.
                        </p>

                        <ul class="tags">
                          <li>
                            <a href="#">Common goals</a>
                          </li>
                          <li>
                            <a href="#">Trust</a>
                          </li>
                          <span class="empty_break"></span>
                          <li>
                            <a href="#">Empathetic</a>
                          </li>
                          <li>
                            <a href="#">Cross functional</a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </swiper-slide>
                <swiper-slide class="item">
                  <div class="col-md-12">
                    <div class="company_profile_card">
                      <h3>Responsibility</h3>
                      <div class="details">
                        <p>
                          Diligent and responsible, taking practical actions.
                          Possessing an entrepreneurial spirit, addressing tasks
                          promptly, correcting mistakes quickly, working
                          steadfastly, daring to take responsibility, pursuing
                          success, and never admitting defeat.
                        </p>

                        <ul class="tags">
                          <li>
                            <a href="#">Practical</a>
                          </li>
                          <li>
                            <a href="#">Responsible</a>
                          </li>
                          <span class="empty_break"></span>
                          <li>
                            <a href="#">Ownership</a>
                          </li>
                          <li>
                            <a href="#">Reflection</a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </swiper-slide>
                <swiper-slide class="item">
                  <div class="col-md-12">
                    <div class="company_profile_card">
                      <h3>Innovation</h3>
                      <div class="details">
                        <p>
                          Innovation-driven, pursuing excellence. Rejecting
                          complacency and stagnation, maintaining curiosity
                          towards new things, continually bringing value to the
                          business through innovative products, services, and
                          management modelst
                        </p>

                        <ul class="tags">
                          <li>
                            <a href="#">Inspiring</a>
                          </li>
                          <li>
                            <a href="#">Open</a>
                          </li>
                          <span class="empty_break"></span>
                          <li>
                            <a href="#">Innovative</a>
                          </li>
                          <li>
                            <a href="#">Sharing</a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </swiper-slide>
              </swiper>
              <div class="custom_buttons">
                <button class="prev" @click="leftSlide">
                  <img src="../../assets/images/chevron.png" alt="" />
                </button>
                <span class="count"
                  >{{ currentSlide }} / {{ slideLength }}</span
                >
                <button class="next" @click="rightSlide">
                  <img src="../../assets/images/chevron.png" alt="" />
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="content hide_temp">
          <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4">
              <div class="box">
                <div class="img_wrap">
                  <img
                    src="../../assets/images/vision.svg"
                    alt="corporate_img"
                  />
                </div>
                <div class="text_wrap">
                  <div class="inner">
                    <h3>Vision</h3>
                    <p>
                      We relentlessly champion innovation to to lead and
                      redefine the forefront of the global communication
                      industry.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4">
              <div class="box">
                <div class="img_wrap">
                  <img
                    src="../../assets/images/mission.svg"
                    alt="corporate_img"
                  />
                </div>
                <div class="text_wrap">
                  <div class="inner">
                    <h3>Mission</h3>
                    <p>
                      Empower businesses worldwide with transformative solutions
                      to revolutionize global markets.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4">
              <div class="box">
                <div class="img_wrap">
                  <img src="../../assets/images/goal.svg" alt="corporate_img" />
                </div>
                <div class="text_wrap">
                  <div class="inner">
                    <h3>Goal</h3>
                    <p>
                      Optimize and unify communication resources to drive
                      unparalleled global expansion for businesses.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- recognised_awards -->
    <section class="recognised_awards pb_100 hide_temp">
      <div class="container">
        <div class="sec_heading text-center">
          <h2>Recognised awards/achievements</h2>
        </div>
        <div class="content">
          <ul class="logos_wrap">
            <li>
              <a href="#">
                <img
                  src="../../assets/images/award_logo.png"
                  alt="award_logo"
                />
              </a>
            </li>
            <li>
              <a href="#">
                <img
                  src="../../assets/images/award_logo.png"
                  alt="award_logo"
                />
              </a>
            </li>
            <li>
              <a href="#">
                <img
                  src="../../assets/images/award_logo.png"
                  alt="award_logo"
                />
              </a>
            </li>
            <li>
              <a href="#">
                <img
                  src="../../assets/images/award_logo.png"
                  alt="award_logo"
                />
              </a>
            </li>
            <li>
              <a href="#">
                <img
                  src="../../assets/images/award_logo.png"
                  alt="award_logo"
                />
              </a>
            </li>
          </ul>
        </div>
      </div>
    </section>

    <!-- Worldwide pressence -->
    <section class="worldwide_sec pb_100">
      <div class="container">
        <div class="sec_heading text-center">
          <h2>Worldwide Presence</h2>
        </div>
        <div class="content">
          <div class="map_area">
            <div class="map_img_wrap">
              <img src="../../assets/images/map_1.png" alt="map" />
            </div>

            <div class="locations_wrap">
              <ul class="locations">
                <li
                  v-for="(location, index) in locations"
                  :key="index"
                  class="location"
                  @mouseover="showLocation(index)"
                  @mouseleave="hideLocation(index)"
                  :class="[
                    location.countryClass,
                    { active: activeLocation === index },
                  ]"
                >
                  <div class="lcmark">
                    <div class="icon">
                      <img
                        src="../../assets/images/location_mark.png"
                        alt="location_mark"
                      />
                    </div>
                    <h4 class="country">{{ location.country }}</h4>
                  </div>
                  <div class="info">
                    <h5>{{ location.country }}</h5>
                    <a
                      v-if="location.contactNumber"
                      :href="'tel:' + location.contactNumber"
                      class="tel"
                      ><span class="strong">Tel:</span>
                      {{ location.contactNumber }}</a
                    >
                    <p
                      v-if="location.address"
                      @click="copyTextNoInput(location)"
                    >
                      <span class="strong">Address: </span>
                      {{ location.address }}
                    </p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- History -->
    <section class="history_sec pb_200">
      <div class="container">
        <div class="sec_heading text-center">
          <h2>A brief history of NXCLOUD</h2>
        </div>
        <div class="content">
          <div class="history_wrapper">
            <div class="inner">
              <ul class="history_listing">
                <li
                  :class="{ active: activeHistory === index }"
                  v-for="(history, index) in histories"
                  :key="index"
                  @mouseover="showHistory(index)"
                >
                  <div class="left">
                    <button data-history="history_1">
                      <span>{{ history.year }}</span>
                    </button>
                  </div>
                  <div class="right">
                    <div
                      class="text_wrap"
                      v-for="item in history.content"
                      :key="item"
                    >
                      <h3>{{ item.title }}</h3>
                      <p>{{ item.desc }}</p>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="cts">
      <img
        src="../../assets/images/footer-shape.png"
        alt=""
        class="ftr_shape"
      />
      <div class="container">
        <div class="row row-cts">
          <div class="col-md-8">
            <h3 class="archived-hdng cts-hdng">
              Start offering your customers a better service experience
            </h3>
          </div>

          <div class="col-md-4">
            <div class="cts-btn">
              <router-link to="/sign-up" class="btn btn-success"
                >Get Started</router-link
              >
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
</template>

<script>
// import Swiper core and required modules
import {
  Navigation,
  Pagination,
  Scrollbar,
  A11y,
  Autoplay,
} from "swiper/modules";

// Import Swiper Vue.js components
import { Swiper, SwiperSlide } from "swiper/vue";

// Import Swiper styles
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";
import "swiper/css/autoplay";

import { ref } from "vue";

export default {
  name: "CompanyPage",
  components: {
    Swiper,
    SwiperSlide,
  },
  setup() {
    const currentSlide = ref(1); // Initialize currentSlide with initial value 1
    const slideLength = ref(1); // Initialize slideLength with initial value 1

    // For Number pagination
    const coreValuesSliderSwiper = (swiper) => {
      slideLength.value = swiper.slides.length;
      swiper.on("slideChange", () => {
        currentSlide.value = swiper.realIndex + 1;
      });
    };

    const coreValuesSliderSlideChange = () => {};

    return {
      currentSlide,
      slideLength,
      coreValuesSliderSwiper,
      coreValuesSliderSlideChange,
      modules: [Navigation, Pagination, Scrollbar, A11y, Autoplay],
    };
  },
  data() {
    return {
      activeLocation: null,
      locations: [
        {
          country: "Shenzhen, China",
          countryClass: "shenzhen",
          contactNumber: "400-7800-900",
          address:
            "6/F Room601 Building A1, Kexing Science Park No .15 Keyuan Road, Nanshan District Shenzhen 518000, Guangdong Province China ",
        },
        {
          country: "Netherlands",
          countryClass: "netherlands",
          contactNumber: "",
          address: "",
        },
        {
          country: "Hong Kong",
          countryClass: "hongkong",
          contactNumber: "",
          address:
            " Room 803 8/F, Lai Cheong Factory Bldg., 479-479A Castle Peak Road, Cheung Sha Wan, Kowloon, Hong Kong",
        },
        {
          country: "Philippines",
          countryClass: "philippines",
          contactNumber: "",
          address: "",
        },
        {
          country: "Indonesia",
          countryClass: "indonesia",
          contactNumber: "",
          address: "",
        },
        {
          country: "Singapore",
          countryClass: "singapore",
          contactNumber: "",
          address: "Funan 05-139 109 North Bridge Rd Singapore 179097",
        },
        {
          country: "Malaysia",
          countryClass: "malaysia",
          contactNumber: "",
          address: "",
        },
        {
          country: "Vietnam",
          countryClass: "vietnam",
          contactNumber: "",
          address: "",
        },
        {
          country: "California, USA",
          countryClass: "california",
          contactNumber: "",
          address:
            " 1601 McCarthy Blvd Milpitas 95035, California United States of America",
        },
      ],
      activeHistory: 0,
      histories: [
        {
          year: 2018,
          content: [
            {
              title: "March",
              desc: "Official founding of NXCLOUD in Singapore, with branches and offices in the USA, Indonesia, and Malaysia.",
            },
            {
              title: "August",
              desc: "Official launch of Independent R&D cloud communication platform.",
            },
          ],
        },
        {
          year: 2019,
          content: [
            {
              title: "June",
              desc: "Official launch of the SaaS product AICC.",
            },
          ],
        },
        {
          year: 2021,
          content: [
            {
              title: "May",
              desc: "NXCLOUD joined the GSMA Association and became its official corporate member.",
            },
          ],
        },
        {
          year: 2022,
          content: [
            {
              title: "May",
              desc: "NXCLOUD became the official Business Messaging Partner for Viber Business.",
            },
            {
              title: "August",
              desc: "NXCLOUD became the official authorized and authenticated solution provider for WhatsApp Business.",
            },
          ],
        },
        {
          year: 2023,
          content: [
            {
              title: "January",
              desc: "Promoted to “Select” level in WhatsApp Business Solution Provider.",
            },
            {
              title: "April",
              desc: "Official global launch of NXCLOUD SaaS product NXLink.",
            },
            {
              title: "September",
              desc: "NXCLOUD participated at ACC 2023 as a Gold Partner.",
            },
            {
              title: "December",
              desc: "NXCLOUD became the official business provider for Zalo.",
            },
          ],
        },
      ],
    };
  },
  methods: {
    showLocation(index) {
      this.activeLocation = index; // Set active location index when hovering
    },
    hideLocation() {
      this.activeLocation = null; // Reset active location index when mouse leaves
    },
    showHistory(index) {
      this.activeHistory = index; // Set active History index when hovering
    },
    copyTextNoInput(location) {
      let text = location.address;
      // console.log(text);
      let textCopied = document.createElement("textarea");
      textCopied.value = text;
      document.body.appendChild(textCopied);
      textCopied.select();
      document.execCommand("copy");
      document.body.removeChild(textCopied);
      alert("Address:\n" + text);
    },
    leftSlide(event) {
      const currSlider = event.target.closest(".swiperSlider");
      const prevButton = currSlider.querySelector(".swiper-button-prev");
      if (prevButton) {
        prevButton.click();
      } else {
        console.error("Previous button not found");
      }
    },
    rightSlide(event) {
      const currSlider = event.target.closest(".swiperSlider");
      const nextButton = currSlider.querySelector(".swiper-button-next");
      if (nextButton) {
        nextButton.click();
      } else {
        console.error("Next button not found");
      }
    },
  },
};
</script>
