<template>
  <main>
    <section class="container-fluid homeBanner textDark">
      <div class="container">
        <div class="row d-flex justify-content-center flex-md-reverse">
          <div class="col-12 col-sm-10 col-md-11 col-lg-10 col-xl-11">
            <div class="row">
              <div class="col-12 col-md-6 col-lg-7 mt-4 mt-md-0">
                <img src="../../assets/images/login_banner.png" alt="" />
              </div>
              <div class="col-12 col-md-6 col-lg-5 d-flex align-items-center">
                <div class="inner w-100">
                  <h1 class="hdng">登录</h1>

                  <div class="formTab">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                      <li class="nav-item" role="presentation">
                        <button
                          class="nav-link active"
                          id="login-tab"
                          data-bs-toggle="tab"
                          data-bs-target="#login-tab-pane"
                          type="button"
                          role="tab"
                          aria-controls="login-tab-pane"
                          aria-selected="true"
                        >
                        登录
                        </button>
                      </li>
                      <li class="nav-item" role="presentation">
                        <button
                          class="nav-link"
                          id="employee-tab"
                          data-bs-toggle="tab"
                          data-bs-target="#employee-tab-pane"
                          type="button"
                          role="tab"
                          aria-controls="employee-tab-pane"
                          aria-selected="false"
                        >
                        员工登录
                        </button>
                      </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                      <div
                        class="tab-pane fade show active"
                        id="login-tab-pane"
                        role="tabpanel"
                        aria-labelledby="login-tab"
                        tabindex="0"
                      >
                        <form action="">
                          <label for="phone">
                            <input
                              type="text"
                              id="user-phone"
                              autocomplete="on"
                              placeholder="电话（国家代码 + 电话）/ 电子邮件 / 用户名"
                              v-model="userFormData.formData.account"
                              @input="checkUserField"
                            />
                            <div
                              v-if="!userFormData.errors.showErrorUser"
                              class="errorInput"
                            >
                              Account can not be empty
                            </div>
                          </label>

                          <label for="password">
                            <input
                              type="password"
                              id="user-password"
                              placeholder="密码"
                              autocomplete="current-password"
                              v-model="userFormData.formData.password"
                              @input="checkPassField"
                            />
                            <div
                              v-if="!userFormData.errors.showErrorPass"
                              class="errorInput"
                            >
                              Please Enter Password
                            </div>
                          </label>

                          <div class="row captcha_fp">
                            <div class="col-6 col-lg-6 mb-2 mb-lg-0">
                              <img
                                src="../../assets/images/captcha.png"
                                alt=""
                              />
                            </div>
                            <div class="col-6 col-lg-6 mb-2 mb-lg-0">
                              <router-link to="/zh-forget-password">
                                忘记密码？
                              </router-link>
                            </div>
                          </div>

                          <div class="submitWrapper">
                            <button
                              class="cmn_btn light"
                              @click="submitLoginForm"
                            >
                            登录
                              <svg
                                width="18"
                                height="19"
                                viewBox="0 0 18 19"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                                <path
                                  d="M10.5 4.25L15.75 9.5M15.75 9.5L10.5 14.75M15.75 9.5L2.25 9.5"
                                  stroke="#85C100"
                                  stroke-width="2"
                                  stroke-linecap="round"
                                  stroke-linejoin="round"
                                />
                              </svg>
                            </button>
                            <!-- Loader -->
                            <div
                              v-if="userFormData.errors.isLoginSubmit"
                              class="loader"
                            >
                              <div class="tm-ring">
                                <div></div>
                                <div></div>
                                <div></div>
                                <div></div>
                              </div>
                            </div>
                          </div>

                          <div
                            v-if="userFormData.errors.messageAfterSubmit"
                            :class="{
                              error: userFormData.errors.messageAfterSubmit,
                            }"
                            class="messageAfterSubmit"
                          >
                            {{ userFormData.errors.messageAfterSubmit }}
                          </div>

                          <p class="info">
                            还没有账号？
                            <router-link to="/zh-sign-up">
                              现在注册
                            </router-link>
                          </p>
                        </form>
                      </div>
                      <div
                        class="tab-pane fade"
                        id="employee-tab-pane"
                        role="tabpanel"
                        aria-labelledby="employee-tab"
                        tabindex="0"
                      >
                        <form action="">
                          <label for="phone">
                            <input
                              type="text"
                              id="emp-phone"
                              placeholder="手机号码"
                              v-model="empFormData.formData.account"
                              @input="checkEmpPhoneField"
                            />
                            <div
                              v-if="!empFormData.errors.showErrorPhone"
                              class="errorInput"
                            >
                              Please Enter Mobile Number
                            </div>
                          </label>

                          <label for="e_username">
                            <input
                              type="text"
                              id="emp-username"
                              placeholder="员工用户名"
                              v-model="code"
                              @input="checkEmpAccountField"
                            />
                            <div
                              v-if="!empFormData.errors.showErrorUser"
                              class="errorInput"
                            >
                              Please Enter Employee Username
                            </div>
                          </label>

                          <label for="password">
                            <input
                              type="password"
                              id="emp-password"
                              placeholder="密码"
                              v-model="empFormData.formData.password"
                              @input="checkEmpPassField"
                            />
                            <div
                              v-if="!empFormData.errors.showErrorPass"
                              class="errorInput"
                            >
                              Please Enter Password
                            </div>
                          </label>

                          <div class="row captcha_fp">
                            <div class="col-12 col-md-6 col-lg-6 mb-2 mb-lg-0">
                              <img
                                src="../../assets/images/captcha.png"
                                alt=""
                              />
                            </div>
                            <div class="col-12 col-md-6 col-lg-6 mb-2 mb-lg-0">
                              <router-link to="/zh-forget-password">
                                忘记密码？
                              </router-link>
                            </div>
                          </div>

                          <div class="submitWrapper">
                            <button
                              class="cmn_btn light"
                              @click="submitSubLoginForm"
                            >
                            登录
                              <svg
                                width="18"
                                height="19"
                                viewBox="0 0 18 19"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                                <path
                                  d="M10.5 4.25L15.75 9.5M15.75 9.5L10.5 14.75M15.75 9.5L2.25 9.5"
                                  stroke="#85C100"
                                  stroke-width="2"
                                  stroke-linecap="round"
                                  stroke-linejoin="round"
                                />
                              </svg>
                            </button>

                            <!-- Loader -->
                            <div
                              v-if="empFormData.errors.isLoginSubmit"
                              class="loader"
                            >
                              <div class="tm-ring">
                                <div></div>
                                <div></div>
                                <div></div>
                                <div></div>
                              </div>
                            </div>
                          </div>

                          <div
                            v-if="empFormData.errors.messageAfterSubmit"
                            :class="{
                              error: empFormData.errors.messageAfterSubmit,
                            }"
                            class="messageAfterSubmit"
                          >
                            {{ empFormData.errors.messageAfterSubmit }}
                          </div>

                          <p class="info">
                            没有帐户？
                            <router-link to="/zh-sign-up">
                              立即注册
                            </router-link>
                          </p>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="cts">
      <img
        src="../../assets/images/footer-shape.png"
        alt=""
        class="ftr_shape"
      />
      <div class="container">
        <div class="row row-cts">
          <div class="col-md-8">
            <h3 class="archived-hdng cts-hdng">
              开始为您的客户提供 <br />
              更优质的服务体验
            </h3>
          </div>
          <div class="col-md-4">
            <div class="cts-btn">
              <router-link to="/zh-sign-up" class="btn btn-success">
                开始使用
              </router-link>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
</template>

<script>
import axios from "axios";
import Cookies from "cookies-js";
export default {
  name: "ZhLogin",
  data() {
    return {
      code: "",
      userFormData: {
        errors: {
          showErrorUser: true,
          showErrorPass: true,
          isLoginSubmit: false,
          messageAfterSubmit: "",
        },
        formData: {
          account: "",
          password: "",
        },
      },
      empFormData: {
        errors: {
          showErrorPhone: true,
          showErrorUser: true,
          showErrorPass: true,
          isLoginSubmit: false,
          messageAfterSubmit: "",
        },
        formData: {
          account: "",
          password: "",
        },
      },
    };
  },
  methods: {
    // user form code
    // display errors on input
    checkUserField() {
      if (!this.userFormData.formData.account.trim()) {
        this.userFormData.errors.showErrorUser = false;
      } else {
        this.userFormData.errors.showErrorUser = true;
      }
    },
    checkPassField() {
      if (!this.userFormData.formData.password.trim()) {
        this.userFormData.errors.showErrorPass = false;
      } else {
        this.userFormData.errors.showErrorPass = true;
      }
    },
    // display errors on input

    // submit login form
    submitLoginForm(event) {
      event.preventDefault();

      //  check if fields are empty
      if (!this.userFormData.formData.account.trim()) {
        this.userFormData.errors.showErrorUser = false;
      }
      if (!this.userFormData.formData.password.trim()) {
        this.userFormData.errors.showErrorPass = false;
        return;
      }
      //  check if fields are empty

      this.userFormData.errors.isLoginSubmit = true;

      // if(this.userFormData.formData.account != "" && this.userFormData.formData.password != ""){
      axios
        .post(
          "https://testadmin.nxcloud.com:10001/api/public/userLogin",
          this.userFormData.formData,
          {
            headers: {
              "Content-Language": "EN",
              "Content-Type": "application/json",
            },
          }
        )
        .then((response) => {
          console.log(response);
          this.userFormData.errors.isLoginSubmit = false;
          this.userFormData.errors.messageAfterSubmit = response.data.msg;
          let data = response.data.data;
          const result = {
            ...data.customer,
            ...data,
          };
          Cookies.set("user", result.name);
          Cookies.set("usertoken", result.usertoken);
          Cookies.set("currency", result.currency);
          Cookies.set("balance", result.balance);
          Cookies.set("credit_balance", result.credit_balance);
          Cookies.set("subUserToken", result.subUserToken);
          Cookies.set("enable_product", result.enable_product);
          // Cookies.set("phone", takePhone(result.phone));
          Cookies.set("uin", result.id);
          // window.location.href = 'https://testclient1.nxcloud.com/console/home';
        })
        .catch((error) => {
          console.error(error);
        });
      // }
    },

    // Sub User Login
    checkEmpPhoneField() {
      if (!this.empFormData.formData.account.trim()) {
        this.empFormData.errors.showErrorPhone = false;
      } else {
        this.empFormData.errors.showErrorPhone = true;
      }
    },
    checkEmpAccountField() {
      if (!this.code.trim()) {
        this.empFormData.errors.showErrorUser = false;
      } else {
        this.empFormData.errors.showErrorUser = true;
      }
    },
    checkEmpPassField() {
      if (!this.empFormData.formData.password.trim()) {
        this.empFormData.errors.showErrorPass = false;
      } else {
        this.empFormData.errors.showErrorPass = true;
      }
    },

    // submit login form
    submitSubLoginForm(event) {
      event.preventDefault();

      //  check if fields are empty
      if (!this.empFormData.formData.account.trim()) {
        this.empFormData.errors.showErrorPhone = false;
      }
      if (!this.code.trim()) {
        this.empFormData.errors.showErrorUser = false;
      }
      if (!this.empFormData.formData.password.trim()) {
        this.empFormData.errors.showErrorPass = false;
        return;
      }
      //  check if fields are empty

      this.empFormData.errors.isLoginSubmit = true;

      // if(this.userFormData.formData.account != "" && this.userFormData.formData.password != ""){
      axios
        .post(
          "https://testclient.nxcloud.com/api/subCustomerLogin",
          this.userFormData.formData,
          {
            headers: {
              "Content-Language": "EN",
              "Content-Type": "application/json",
            },
          }
        )
        .then((response) => {
          console.log(response);
          this.empFormData.errors.isLoginSubmit = false;
          this.empFormData.errors.messageAfterSubmit = response.data.info;
          let data = response.data.data;
          const result = {
            ...data.customer,
            ...data,
          };
          console.log(result);
          // Cookies.set("user", result.name);
          // Cookies.set("usertoken", result.usertoken);
          // Cookies.set("currency", result.currency);
          // Cookies.set("balance", result.balance);
          // Cookies.set("credit_balance", result.credit_balance);
          // Cookies.set("subUserToken", result.subUserToken);
          // Cookies.set("enable_product", result.enable_product);
          //   // Cookies.set("phone", takePhone(result.phone));
          // Cookies.set("uin", result.id);
          // window.location.href = 'https://testclient1.nxcloud.com/console/home';
        })
        .catch((error) => {
          console.error(error);
        });
      // }
    },
    // Sub User Login
  },
};
</script>
<style scoped></style>
