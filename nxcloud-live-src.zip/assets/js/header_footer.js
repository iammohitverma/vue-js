jQuery(document).ready(function (e) {
    // Header Using jQuery
    $.ajax({
        url: '../inc/header.html',
        type: 'GET',
        dataType: 'html',
        success: function (headerHtml) {
            // Insert the fetched HTML into the result container
            jQuery("html body main").before(headerHtml);
        },
        error: function (error) {
            console.error('Error fetching HTML:', error);
        }
    });
    // Footer Using jQuery
    $.ajax({
        url: '../inc/footer.html',
        type: 'GET',
        dataType: 'html',
        success: function (footer) {
            // Insert the fetched HTML into the result container
            jQuery("html body main").after(footer);
        },
        error: function (error) {
            console.error('Error fetching HTML:', error);
        }
    });
});
