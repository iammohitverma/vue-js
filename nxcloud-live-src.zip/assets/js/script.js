// wow animation
new WOW().init();

// owl carousel for home page 
$('.owl-carousel').owlCarousel({
  loop: true,
  margin: 10,
  nav: true,
  items: 1,
  autoplay: true,
  autoplayTimeout: 4000
})

$(".owl-prev").html('<img src="./assets/images/chevron.png" alt="">');
$(".owl-next").html('<img src="./assets/images/chevron.png" alt="">');


//for mobile menu 
jQuery(document).ready(function () {

  function funcAfterHeaderFooterLoaded() {
    // Get the height of the header
    let headerHeight = jQuery("header").height();

    // Add a CSS variable to the body element
    jQuery("body").css("--headerHeight", headerHeight + "px");

    jQuery("header .toggle-menu").click(function () {
      jQuery(".navigation_wrap").slideToggle();
      jQuery(this).toggleClass("active");
    });
    jQuery("header .submenu_arrow").click(function () {
      jQuery(this).closest(".has_submenu").find(".submenu").slideToggle();
      jQuery(this).toggleClass("active");
    });


    // active tab on click
    jQuery(".tabClickLink").click(function (e) {
      let currTabLinkClicked = $(this).attr("data-tabclick");
      let pageUrl = $(this).attr("data-url");
      if (jQuery(`[data-bs-target="#${currTabLinkClicked}"`).length) {
        jQuery(`[data-bs-target="#${currTabLinkClicked}"`).click();
        jQuery(".prod_desc_section")[0].scrollIntoView();
      } else {
        sessionStorage.setItem("openingTab", currTabLinkClicked);
        window.location.href = pageUrl;
      }
    });

    // get item from storage on load 
    let openingTab = sessionStorage.getItem("openingTab");
    if (openingTab) {
      jQuery(`[data-bs-target="#${openingTab}"`).click();
      jQuery(".prod_desc_section")[0].scrollIntoView();
      sessionStorage.clear();
    }


    // header language select
    let base_url = "https://www.nxcloud.sg/";

    let currLang = sessionStorage.getItem("lang") || "EN"; // Default language set to English if sessionStorage is empty
    let currUrl = window.location.href;

    console.log(currLang);
    console.log(currUrl);

    // Split the URL by slashes and get the last part
    let parts = currUrl.split("/");
    let valueAfterLastSlash = parts[parts.length - 1];

    if((currLang == "CN") && (currUrl == base_url)) {
      window.location.href = base_url + "zh.html";
    } else if((currLang == "CN") && (currUrl != base_url) && (valueAfterLastSlash != "zh.html") && (!currUrl.includes("zh-"))){
      window.location.href = base_url + "zh-" + valueAfterLastSlash;
    }

    console.log(valueAfterLastSlash); // Output: "resource"

    jQuery("header .lang select").val(currLang); // Set the language select box value

    jQuery("header .lang select").change(function () {
      debugger
      currLang = jQuery(this).val();
      sessionStorage.setItem("lang", currLang);

      if (currLang === "CN") {
        // If currently on English home page, redirect to Chinese home page
        if((valueAfterLastSlash != "zh.html") && (!currUrl.includes("zh-") && (currUrl != base_url))){
            window.location.href = base_url + "zh-" + valueAfterLastSlash;
        } else if (!currUrl.includes(base_url + "zh.html")) {
          window.location.href = base_url + "zh.html";
        }
      } else {
        // If currently on Chinese home page, redirect to English home page
        if (currUrl === base_url + "zh.html") {
          window.location.href = base_url;
        } else if (currUrl.includes("zh-")) {
          let urlWithoutZh = currUrl.replace("zh-", ""); // Remove "zh-" from the URL
          window.location.href = urlWithoutZh;
        }
      }
    });



    // click to copy address
    $(".worldwide_sec .content .map_area .locations_wrap .locations .location .info p").on("click", function () {
      // Select the text from the address paragraph
      var addressToCopy = $(this).text();

      // Create a temporary input element and append it to the body
      var tempInput = $("<input>");
      $("body").append(tempInput);

      // Set the value of the input to the address text
      tempInput.val(addressToCopy).select();

      // Copy the selected text to the clipboard
      document.execCommand("copy");

      // Remove the temporary input element
      tempInput.remove();

      // Alert or notify the user that the address has been copied (optional)
      alert("Address has been copied to the clipboard: " + addressToCopy);
    });

    // worldwide_sec on company-page add active class on hover
    $(".worldwide_sec .locations .location").hover(
      function () {
        $(this).addClass("active");
      },
      function () {
        $(this).removeClass("active");
      }
    );


    // chatbot append and click to add active class
    let chatBotHtml = `<div class="chatbot_wrap">
    <button class="chatbot_btn">
      <img src="./assets/images/Chat.svg" alt="chatbot" />
    </button>
    <ul class="list">
      <li>
        <a
          href="https://wa.me/6580380304?text=Enquiry%20about%20NXCLOUD"
          target="_blank"
        >
          <i class="icon">
            <img src="./assets/images/whatsapp_bot.svg" alt="whatsapp_bot" />
          </i>
          <span class="text">Whatsapp</span>
        </a>
      </li>
      <li>
        <a href="viber://chat?number=6580380304">
          <i class="icon">
            <img src="./assets/images/viber_bot.svg" alt="viber_bot" />
          </i>
          <span class="text">Viber</span>
        </a>
      </li>
      <li class="contact_sec chatbotFormPopup">
        <div class="chatbotFormPopupBox">
          <div class="form_wrap">
            <h4 class="heading">Contact Us</h4>
            <div class="form_box">
              <form>
                <div class="row">
                  <div class="col-md-12">
                    <div class="input_wrap">
                      <label>Full Name <span class="required">*</span></label>
                      <input type="text" />
                    </div>
                  </div>

                  <!---<div class="col-md-12">
                    <div class="input_wrap">
                      <label>Company <span class="required">*</span></label>
                      <input type="text" />
                    </div>
                  </div>--->

                  
                  <div class="col-md-12">
                    <div class="input_wrap">
                      <label>Email <span class="required">*</span></label>
                      <input type="email" placeholder="e.g anthony@gmail.com"/>
                    </div>
                  </div>

                  <div class="col-md-12">
                    <div class="input_wrap">
                      <label>Phone number <span class="required">*</span></label>
                      <input type="text" placeholder="+44 0000 0000"/>
                    </div>
                  </div>
                 
                  <div class="col-md-12">
                    <div class="input_wrap">
                      <label>Message <span class="required">*</span></label>
                      <textarea placeholder="Please briefly describe your needs and one of our dedicated consultants will contact you"></textarea>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="options">
                      <div class="row">
                        <div class="col-md-12">
                          <p class="info danger">* Alternatively, you may email to  <a href="mailto:info@nxcloud.com">info@nxcloud.com</a></p>
                        </div>

                       

                      </div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="submit_wrap">
                      <input type="submit" value="Send Now" class="btn"/>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="thankyou_wrap" style="display: none;">
            <div class="icon_wrap">
              <img src="./assets/images/check-circle.svg" alt="check_icon"/>
            </div>
            <div class="text_wrap">
              <h4>Thank you</h5>
              <p>your message <br/>
              have been sent</p>
              <a href="javascript:void(0)" class="btn done_btn">Done</a>
            </div>
          </div>
          <button class="closePopup"></button>
        </div>
        <a href="javascript:void(0);" target="_blank" class="chatbot_icon">
          <i class="icon">
            <img
              src="./assets/images/email.svg"
              alt="email"
            />
          </i>
          <span class="text">Email</span>
        </a>
      </li>
    </ul>
  </div>`;
    $('.main-footer').prepend(chatBotHtml);
    // click on main bottom fixed button trigger
    $('.chatbot_wrap .chatbot_btn').click(function () {
      $(".chatbot_wrap").toggleClass("active");
      $(".chatbotFormPopupBox").removeClass("active");
    });
    // click on message icon form popup open
    $('.chatbot_wrap .chatbotFormPopup .chatbot_icon').click(function (e) {
      e.preventDefault();
      $(".chatbotFormPopupBox").toggleClass("active");
      $(".chatbot_wrap .chatbotFormPopupBox").removeClass("submitted");
      $('.chatbot_wrap .chatbotFormPopup .closePopup').show();
      $(".chatbot_wrap .form_wrap").show();
      $(".chatbot_wrap .thankyou_wrap").hide();
    });
    // popup form submit 
    $('.chatbot_wrap .chatbotFormPopup form').submit(function (e) {
      e.preventDefault();
      $(".chatbot_wrap .form_wrap").hide();
      $(".chatbot_wrap .thankyou_wrap").show();
      $(".chatbot_wrap .chatbotFormPopupBox").addClass("submitted");
      $('.chatbot_wrap .chatbotFormPopup .closePopup').hide();
    });
    // popup form thankyou message Done button
    $('.chatbot_wrap .chatbotFormPopup .thankyou_wrap .done_btn').click(function (e) {
      $(".chatbot_wrap .form_wrap").hide();
      $(".chatbot_wrap .thankyou_wrap").hide();
      $(".chatbot_wrap .chatbotFormPopupBox").removeClass("active");
      $(".chatbot_wrap .chatbotFormPopupBox").removeClass("submitted");
      $('.chatbot_wrap .chatbotFormPopup .closePopup').hide();
    });
    // popup form close button
    $('.chatbot_wrap .chatbotFormPopup .closePopup').click(function (e) {
      $(".chatbotFormPopupBox").removeClass("active");
    });

    // history section timeline
    $('.history_sec li').hover(function (e) {
      $(".history_sec li").removeClass("active");
      $(this).addClass("active");
    });
    $('.history_sec li').click(function (e) {
      $(this)[0].scrollIntoView({ behavior: 'smooth', block: 'start' });
    });


    //(Developer page) for GitHub Pages, when you click the option in the sidebar to view
    jQuery(".developer_page .sidebar_options_wrap [data-github]").eq(0).addClass("active");
    setTimeout(() => {
      jQuery(".developer_page .sidebar_options_wrap [data-github]").eq(0).click();
    }, 100);

    jQuery(".developer_page .sidebar_options_wrap [data-github]").click(function (e) {
      e.preventDefault();
      jQuery(".developer_page .center_area .git_section_area").hide();
      jQuery(".developer_page .center_area .pageLoad_loader").show();
      jQuery(".developer_page .sidebar_options_wrap [data-github]").removeClass("active");
      jQuery(this).addClass("active");
      let githubPageUrl = jQuery(this).attr("data-github");
      //  Ajax for fetch github pages
      $.ajax({
        url: `./github_pages/${githubPageUrl}`,
        type: 'GET',
        dataType: 'html',
        success: function (githubPageHTMl) {
          // Insert the fetched HTML into the result container
          setTimeout(() => {
            jQuery(".developer_page .center_area .pageLoad_loader").hide();
            jQuery(".developer_page .center_area .git_section_area").show();
            jQuery(".developer_page .center_area .git_section_area").html("");
            jQuery(".developer_page .center_area .git_section_area").append(githubPageHTMl);
          }, 500);
        },
        error: function (error) {
          console.error('Error fetching HTML:', error);
        }
      });
    });


    // Developer page search functionality 
    $(".search_field").keyup(function (e) {
      let currVal = $(this).val();
      console.log(currVal);
      searchDevFilter(currVal);
    });

    function searchDevFilter(value) {
      $(".accordion-body ul li a, .accordion-body ul li a .text b").each(function () {
        console.log("searchvalue " + value);
        let option = $(this).text().toLowerCase();
        console.log("optionValue " + option);
        let filterVal = value.toLowerCase(); // Make sure to replace this with your actual filter value
        if (option.indexOf(filterVal) !== -1) {
          $(this).closest("li").addClass("show");
          $(this).closest("li").removeClass("hide");
        } else {
          $(this).closest("li").addClass("hide");
          $(this).closest("li").removeClass("show");
        }

        // Check if all li elements have the hide class, then add hide to accordion item
        $(".accordion-body ul").each(function () {
          let allLiHaveHideClass = true;

          $(this).find("li").each(function () {
            if (!$(this).hasClass("hide")) {
              allLiHaveHideClass = false;
              return false;  // Break out of the loop early if one li does not have hide class
            }
          });

          if (allLiHaveHideClass) {
            $(this).closest(".accordion-item").addClass("hide").removeClass("show");
          } else {
            $(this).closest(".accordion-item").removeClass("hide").addClass("show");
          }
        });

      });
    }


    // copy to clipboard js
    $(document).on("click", ".ClipboardButton", function (event) {
      // Get the text content to copy
      let closestParent = $(this).closest(".zeroclipboard-container").parent();
      let copiedText = $(closestParent).find("pre").text();

      // Function to copy text to clipboard
      function copyToClipboard(element) {
        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val(element).select();
        document.execCommand("copy");
        alert(element); // Alert the copied text
        $temp.remove();
      }

      // Call the copyToClipboard function with the text content
      copyToClipboard(copiedText);
    });

  }

  setTimeout(funcAfterHeaderFooterLoaded, 250);


});